require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const db = require('./db');
const fin = require('./finance');
const { lucasState } = require('./lucas');

if (!process.env.JWT_SECRET) { console.error('Falta JWT_SECRET en .env'); process.exit(1); }
const SECRET = process.env.JWT_SECRET;
const RETENCION = parseFloat(process.env.RETENCION_FUENTE || '0.04');

const app = express();
app.use(helmet({ contentSecurityPolicy: false })); // permite el script inline y Google Fonts en desarrollo
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 30 }));

const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), SECRET); next(); }
  catch { res.status(401).json({ error: 'Sesión no válida' }); }
};
const token = u => jwt.sign({ id: u.id, email: u.email }, SECRET, { expiresIn: '7d' });

// ---------- Auth ----------
app.post('/api/auth/register', (req, res) => {
  const { email, name, password, consent } = req.body;
  if (!consent) return res.status(400).json({ error: 'Debes autorizar el tratamiento de tus datos.' });
  if (!/^\S+@\S+\.\S+$/.test(email || '') || !name || (password || '').length < 8)
    return res.status(400).json({ error: 'Correo, nombre y contraseña (mín. 8 caracteres) son obligatorios.' });
  try {
    const r = db.prepare('INSERT INTO users (email,name,password_hash,consent_at) VALUES (?,?,?,datetime(\'now\'))')
      .run(email.toLowerCase(), name, bcrypt.hashSync(password, 12));
    res.status(201).json({ token: token({ id: r.lastInsertRowid, email }) });
  } catch { res.status(409).json({ error: 'Ese correo ya está registrado.' }); }
});
app.post('/api/auth/login', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE email=?').get((req.body.email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(req.body.password || '', u.password_hash))
    return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
  res.json({ token: token(u), name: u.name });
});

// ---------- Categorías y movimientos ----------
app.get('/api/categories', auth, (req, res) =>
  res.json(db.prepare('SELECT id,name,(user_id IS NOT NULL) mine FROM categories WHERE user_id IS NULL OR user_id=?').all(req.user.id)));

app.post('/api/categories', auth, (req, res) => {
  const name = (req.body.name || '').trim().slice(0, 60);
  if (!name) return res.status(400).json({ error: 'Escribe un nombre.' });
  res.status(201).json({ id: db.prepare('INSERT INTO categories (user_id,name) VALUES (?,?)').run(req.user.id, name).lastInsertRowid });
});
app.delete('/api/categories/:id', auth, (req, res) => {
  const own = db.prepare('SELECT id FROM categories WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!own) return res.status(404).json({ error: 'Solo puedes borrar tus categorías.' });
  db.prepare('UPDATE transactions SET category_id=NULL WHERE category_id=? AND user_id=?').run(own.id, req.user.id);
  db.prepare('DELETE FROM categories WHERE id=?').run(own.id); res.status(204).end();
});
app.post('/api/transactions', auth, (req, res) => {
  const { type, amount, category_id, note, date } = req.body;
  if (!['gasto', 'ingreso'].includes(type) || !Number.isInteger(amount) || amount <= 0)
    return res.status(400).json({ error: 'Tipo o monto no válido.' });
  const r = db.prepare('INSERT INTO transactions (user_id,category_id,type,amount,note,date) VALUES (?,?,?,?,?,?)')
    .run(req.user.id, category_id || null, type, amount, note || null, date || new Date().toISOString().slice(0, 10));
  res.status(201).json({ id: r.lastInsertRowid });
});
app.get('/api/transactions', auth, (req, res) => {
  const { from = '0000-01-01', to = '9999-12-31' } = req.query;
  res.json(db.prepare(`SELECT t.*, c.name category FROM transactions t LEFT JOIN categories c ON c.id=t.category_id
    WHERE t.user_id=? AND t.date BETWEEN ? AND ? ORDER BY t.date DESC, t.id DESC LIMIT 500`).all(req.user.id, from, to));
});
app.delete('/api/transactions/:id', auth, (req, res) => {
  const r = db.prepare('DELETE FROM transactions WHERE id=? AND user_id=?').run(req.params.id, req.user.id);
  r.changes ? res.status(204).end() : res.status(404).json({ error: 'No encontrado' });
});
app.get('/api/summary', auth, (req, res) => {
  const { from = '0000-01-01', to = '9999-12-31' } = req.query;
  res.json(db.prepare(`SELECT COALESCE(c.name,'Sin categoría') category, t.type, SUM(t.amount) total
    FROM transactions t LEFT JOIN categories c ON c.id=t.category_id
    WHERE t.user_id=? AND t.date BETWEEN ? AND ? GROUP BY 1,2`).all(req.user.id, from, to));
});

// ---------- Calculadora fin de semestre ----------
app.get('/api/budget/daily', auth, (req, res) => {
  const available = +req.query.available, days = +req.query.days;
  if (!(available >= 0) || !Number.isInteger(days) || days < 1) return res.status(400).json({ error: 'Datos no válidos.' });
  res.json(fin.dailyBudget(available, days, +req.query.spentToday || 0));
});

// ---------- Simulador de inversiones ----------
app.get('/api/rates', (_req, res) => res.json(db.prepare('SELECT * FROM rates ORDER BY entity,min_days').all()));

app.post('/api/simulate', auth, (req, res) => {
  const { amount, value, unit, periodicity, entity } = req.body;
  const days = fin.toDays(value, unit);
  const errors = fin.validate({ amount, days, periodicity });
  if (Object.keys(errors).length) return res.status(400).json({ errors });
  const rows = db.prepare('SELECT * FROM rates WHERE ? BETWEEN min_days AND max_days AND ?>=min_amount ORDER BY ea DESC').all(days, amount);
  if (!rows.length) return res.status(404).json({ error: 'No hay entidades con tasa para ese monto y plazo (máx. 1.800 días).' });
  const all = rows.map(r => ({ entity: r.entity, ...fin.simulate({ amount, days, periodicity, ea: r.ea, retentionRate: RETENCION }) }));
  const pick = entity ? all.find(x => x.entity === entity) : all[0];   // sin entidad = mejor tasa
  if (!pick) return res.status(404).json({ error: 'Esa entidad no tiene tasa para ese monto y plazo.' });
  db.prepare(`INSERT INTO simulations (user_id,entity,amount,days,periodicity,ea,gross,retention,net,maturity)
    VALUES (?,?,?,?,?,?,?,?,?,?)`).run(req.user.id, pick.entity, amount, days, periodicity, pick.ea, pick.gross, pick.retention, pick.net, pick.maturity);
  res.json({ days, retentionRate: RETENCION, ...pick, comparison: all });
});
app.get('/api/simulations', auth, (req, res) =>
  res.json(db.prepare('SELECT * FROM simulations WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id)));

// ---------- Lucas (personaje interactivo) ----------
app.get('/api/lucas', auth, (req, res) => res.json(lucasState(req.user.id, req.query.event)));

// ---------- Derechos del titular (Habeas Data): exportar y borrar ----------
app.get('/api/me/export', auth, (req, res) => res.json({
  user: db.prepare('SELECT id,email,name,created_at FROM users WHERE id=?').get(req.user.id),
  transactions: db.prepare('SELECT * FROM transactions WHERE user_id=?').all(req.user.id),
  simulations: db.prepare('SELECT * FROM simulations WHERE user_id=?').all(req.user.id) }));
app.delete('/api/me', auth, (req, res) => { db.prepare('DELETE FROM users WHERE id=?').run(req.user.id); res.status(204).end(); });

if (require.main === module) app.listen(process.env.PORT || 3000, () => console.log('FinPoli en http://localhost:' + (process.env.PORT || 3000)));
module.exports = app;
