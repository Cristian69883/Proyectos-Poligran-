// Lucas: el parcero financiero. Calcula su estado de ánimo, mensajes, racha, puntos y retos
// a partir de los datos reales del usuario (movimientos y simulaciones guardados en la BD).
const db = require('./db');

const pad = n => String(n).padStart(2, '0');
const iso = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const cop = n => '$' + Math.round(n).toLocaleString('es-CO');
const pick = a => a[Math.floor(Math.random() * a.length)];

const TIPS = [
  'Regla del parcero: apunta el gasto apenas lo hagas, no al final del día. ¡Se te olvidan hasta los cafés!',
  'Antes de pedir domicilio, pregúntate: ¿esto lo cubre el corrientazo de la esquina? Casi siempre sí.',
  'Un CDT a 180 días puede pagarte más que dejar la plata quieta. Pruébalo en el simulador.',
  'Separa primero lo del semestre y después lo demás. Pagar la matrícula a última hora sale caro.',
  'Si te sobran $20.000 al mes, en un año son $240.000. ¡Poquito a poquito!',
  'Compartir streaming con roomies es ahorro puro. Anótalo como categoría propia.',
  'Mira tu categoría más grande del mes: ahí está tu mayor oportunidad de ahorro.',
  'Los gastos hormiga (tintico, dulces, buses sueltos) suman más de lo que crees. Regístralos todos.'
];

function streakOf(userId) {
  const days = new Set(db.prepare('SELECT DISTINCT date FROM transactions WHERE user_id=? ORDER BY date DESC LIMIT 90').all(userId).map(r => r.date));
  let d = new Date();
  if (!days.has(iso(d))) d = addDays(d, -1);        // la racha no se rompe hasta que pase un día sin registrar
  let n = 0; while (days.has(iso(d))) { n++; d = addDays(d, -1); }
  return n;
}

function lucasState(userId, event) {
  const user = db.prepare('SELECT name FROM users WHERE id=?').get(userId) || { name: 'parce' };
  const first = user.name.split(' ')[0];
  const now = new Date(), monthStart = iso(new Date(now.getFullYear(), now.getMonth(), 1)), weekStart = iso(addDays(now, -6));

  const sums = Object.fromEntries(db.prepare('SELECT type, SUM(amount) t FROM transactions WHERE user_id=? AND date>=? GROUP BY type').all(userId, monthStart).map(r => [r.type, r.t]));
  const inc = sums.ingreso || 0, exp = sums.gasto || 0;
  const top = db.prepare(`SELECT COALESCE(c.name,'Sin categoría') n, SUM(t.amount) s FROM transactions t LEFT JOIN categories c ON c.id=t.category_id
    WHERE t.user_id=? AND t.type='gasto' AND t.date>=? GROUP BY n ORDER BY s DESC LIMIT 1`).get(userId, monthStart);
  const movs = db.prepare('SELECT COUNT(*) c FROM transactions WHERE user_id=?').get(userId).c;
  const sims = db.prepare('SELECT COUNT(*) c FROM simulations WHERE user_id=?').get(userId).c;
  const movs7 = db.prepare('SELECT COUNT(*) c FROM transactions WHERE user_id=? AND date>=?').get(userId, weekStart).c;
  const ocio7 = db.prepare(`SELECT COUNT(*) c FROM transactions t JOIN categories c ON c.id=t.category_id
    WHERE t.user_id=? AND t.type='gasto' AND t.date>=? AND c.name='Ocio'`).get(userId, weekStart).c;
  const streak = streakOf(userId);

  const retos = [
    { id: 'racha', titulo: 'Racha de 7 días', desc: 'Registra movimientos 7 días seguidos.', progreso: Math.min(streak, 7), meta: 7, puntos: 100 },
    { id: 'sim', titulo: 'Explorador de inversión', desc: 'Haz tu primera simulación de CDT.', progreso: Math.min(sims, 1), meta: 1, puntos: 50 },
    { id: 'ocio', titulo: 'Semana sin Ocio', desc: 'Cero gastos en Ocio en 7 días (con mínimo 3 movimientos).', progreso: ocio7 === 0 ? Math.min(movs7, 3) : 0, meta: 3, puntos: 80 }
  ].map(r => ({ ...r, hecho: r.progreso >= r.meta }));

  const puntos = movs * 10 + sims * 25 + retos.filter(r => r.hecho).reduce((s, r) => s + r.puntos, 0);
  const nivel = 1 + Math.floor(puntos / 100);
  const titulos = ['Lucas novato', 'Lucas ahorrador', 'Lucas parcero', 'Lucas inversionista'];

  // Estado de ánimo según la salud financiera del mes
  let mood, msg;
  if (!movs) { mood = 'saludo'; msg = `¡Quiubo, ${first}! Soy Lucas, tu parcero de las finanzas. Registremos tu primer movimiento y arrancamos.`; }
  else if (inc === 0 && exp > 0) { mood = 'pensando'; msg = `Veo gastos por ${cop(exp)} este mes pero ningún ingreso. ¿Registramos de dónde viene la plata?`; }
  else if (exp > inc) { mood = 'triste'; msg = `Uy parce, este mes gastaste ${cop(exp - inc)} más de lo que ha entrado.${top ? ` Lo más pesado: ${top.n} (${cop(top.s)}).` : ''} Toca ajustar.`; }
  else if (exp >= inc * 0.8) { mood = 'pensando'; msg = `Ojo, ${first}: ya vas en el ${Math.round(exp / inc * 100)}% de tus ingresos del mes.${top ? ` ${top.n} es lo que más pesa.` : ''}`; }
  else if ((inc - exp) / inc >= 0.3) { mood = 'celebra'; msg = `¡Eso, parce! Llevas ${cop(inc - exp)} de ahorro este mes. ¿Lo probamos en un CDT?`; }
  else { mood = 'feliz'; msg = `Vas bien, ${first}. Te quedan ${cop(inc - exp)} este mes.`; }

  // Reacciones a acciones concretas
  if (event === 'gasto') { if (mood === 'triste') msg = pick([`Anotado, pero cuidado parce: ya estás ${cop(exp - inc)} por encima de tus ingresos.`, `Uy, otro gasto. Vamos ${cop(exp)} este mes, mejor frenamos un poquito.`]); else if (mood === 'saludo') msg = '¡Anotado!'; else msg = pick(['Anotado, parce. Cada peso registrado cuenta.', `Listo, ya quedó. Te quedan ${cop(Math.max(inc - exp, 0))} del mes.`, '¡Buena! Registrar es el primer paso para controlar la plata.']); }
  if (event === 'ingreso') { mood = 'celebra'; msg = pick(['¡Llegó plata! Antes de gastarla, separa lo del semestre.', '¡Qué bien! Anotado el ingreso. ¿Cuánto vas a guardar esta vez?']); }
  if (event === 'categoria') { mood = 'feliz'; msg = 'Categoría nueva lista. ¡Así sí queda a tu medida!'; }
  if (event === 'consejo') { mood = 'pensando'; msg = pick(TIPS); }
  if (event === 'bienvenida' && movs) msg = `¡Qué bueno verte, ${first}! ${streak > 1 ? `Llevas ${streak} días de racha. ` : ''}${msg}`;
  if (event === 'reto' && retos.some(r => r.hecho)) { mood = 'celebra'; msg = '¡Reto cumplido! Eso suma Puntos Poli, parce.'; }

  return { mood, msg, streak, puntos, nivel, titulo: titulos[Math.min(nivel - 1, 3)], siguiente: nivel * 100, retos };
}
module.exports = { lucasState };
