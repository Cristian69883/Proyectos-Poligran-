// Motor financiero (puro, sin acceso a BD → fácil de probar)
const MIN_AMOUNT = 100000, MIN_DAYS = 30;

function validate({ amount, days, periodicity }) {
  const errors = {};
  if (typeof amount !== 'number' || !Number.isFinite(amount) || amount <= 0) errors.amount = 'Ingresa un monto numérico mayor a cero.';
  else if (amount < MIN_AMOUNT) errors.amount = 'El monto mínimo para simular una inversión es de $100.000 COP';
  if (!Number.isInteger(days) || days < MIN_DAYS) errors.days = `El plazo mínimo es de ${MIN_DAYS} días.`;
  if (!['vencimiento', 'mensual'].includes(periodicity)) errors.periodicity = 'Periodicidad no válida.';
  return errors;
}

const toDays = (value, unit) => Math.round(value * ({ dias: 1, meses: 30, anios: 365 }[unit] || NaN));

const localISO = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

function simulate({ amount, days, periodicity, ea, retentionRate = 0.04, from = new Date() }) {
  const factor = Math.pow(1 + ea / 100, days / 365) - 1;      // interés efectivo del plazo
  const gross = Math.round(amount * factor);
  const retention = Math.round(gross * retentionRate);
  const net = gross - retention;                               // regla: neta = bruta − retención
  const maturity = new Date(from); maturity.setDate(maturity.getDate() + days);
  const out = { ea, gross, retention, net, total: amount + net, maturity: localISO(maturity) };
  if (periodicity === 'mensual') {
    const months = Math.max(1, Math.floor(days / 30));
    out.monthlyNet = Math.round(net / months);
    out.payments = months;
  }
  return out;
}

// "Me quedan 23 días y $180.000" → cuánto por día
function dailyBudget(available, daysLeft, spentToday = 0) {
  const base = Math.floor(available / daysLeft);
  return { perDay: base, remainingToday: base - spentToday,
           tomorrow: daysLeft > 1 ? Math.floor((available - spentToday) / (daysLeft - 1)) : 0 };
}
module.exports = { validate, simulate, dailyBudget, toDays, MIN_AMOUNT };
