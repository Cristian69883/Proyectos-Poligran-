const test = require('node:test'); const assert = require('node:assert');
const { validate, simulate, dailyBudget } = require('./finance');
test('monto menor a 100.000 es rechazado', () => assert.match(validate({ amount: 10000, days: 180, periodicity: 'vencimiento' }).amount, /100\.000/));
test('neta = bruta − retención', () => { const r = simulate({ amount: 1000000, days: 180, periodicity: 'vencimiento', ea: 10 }); assert.strictEqual(r.net, r.gross - r.retention); });
test('vencimiento = hoy + plazo', () => { const r = simulate({ amount: 1e6, days: 30, periodicity: 'vencimiento', ea: 10, from: new Date('2026-10-20T12:00:00') }); assert.strictEqual(r.maturity, '2026-11-19'); });
test('presupuesto diario 180000/23', () => assert.strictEqual(dailyBudget(180000, 23).perDay, 7826));
