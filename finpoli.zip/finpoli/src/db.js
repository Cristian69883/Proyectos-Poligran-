// Capa de datos: SQLite (archivo local). Para migrar a PostgreSQL/MySQL solo cambia este archivo.
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const dbPath = process.env.DB_PATH || './data/finpoli.db';
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Si cambia la versión de las tasas, se vuelve a crear la tabla rates con los datos nuevos
const RATES_VERSION = '2026-10-20';
db.exec('CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)');
if ((db.prepare("SELECT v FROM meta WHERE k='rates_version'").get() || {}).v !== RATES_VERSION) db.exec('DROP TABLE IF EXISTS rates');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  consent_at TEXT NOT NULL,            -- autorización de tratamiento de datos (Ley 1581/2012)
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, -- NULL = categoría base "Modo Vida Poli"
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id INTEGER REFERENCES categories(id),
  type TEXT NOT NULL CHECK (type IN ('gasto','ingreso')),
  amount INTEGER NOT NULL CHECK (amount > 0),   -- COP enteros
  note TEXT,
  date TEXT NOT NULL,                            -- YYYY-MM-DD
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tx_user_date ON transactions(user_id, date);
CREATE TABLE IF NOT EXISTS rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity TEXT NOT NULL,
  min_days INTEGER NOT NULL,
  max_days INTEGER NOT NULL,
  ea REAL NOT NULL,                              -- tasa efectiva anual en % (ej. 10.5)
  note TEXT,
  min_amount INTEGER NOT NULL DEFAULT 100000,
  updated_at TEXT NOT NULL DEFAULT (date('now'))
);
CREATE TABLE IF NOT EXISTS simulations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entity TEXT, amount INTEGER, days INTEGER, periodicity TEXT,
  ea REAL, gross INTEGER, retention INTEGER, net INTEGER, maturity TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Semillas
if (db.prepare('SELECT COUNT(*) c FROM categories WHERE user_id IS NULL').get().c === 0) {
  const ins = db.prepare('INSERT INTO categories (name) VALUES (?)');
  ['Semestre / Matrícula', 'Fotocopias e impresiones', 'Transporte (Transmilenio / gasolina / app)',
   'Corrientazo / Café', 'Streaming / Datos / Nequi', 'Arriendo y servicios', 'Mercado', 'Ocio', 'Otros']
    .forEach(n => ins.run(n));
}
if (db.prepare('SELECT COUNT(*) c FROM rates').get().c === 0) {
  // Tasas E.A. de CDT (personas naturales). Fuentes: SFC (corte 13-oct-2026), La República, Rankia, Finanzas Plus, Colombia Mágico.
  // ⚠️ Son referenciales y varían por fuente/fecha: actualízalas desde https://www.superfinanciera.gov.co (Tasas pasivas > CDT).
  const BANDS = [[30, 179, 0], [180, 359, 1], [360, 539, 2], [540, 1800, 3]];   // 90d, 180d, 360d, más de 360d
  const BANKS = [ // [entidad, 90d, 180d, 360d, +360d, monto mínimo]
    ['Banco de Bogotá', 10.62, 11.09, 12.17, 12.71, 100000],
    ['Bancolombia',      9.85, 10.41, 11.84, 11.28, 500000],
    ['Davivienda',      10.78, 10.84, 10.83, 12.11, 100000],
    ['BBVA',             null,  null, 11.04,  null, 100000],
    ['Banco Popular',    null,  null, 10.54,  null, 100000],
    ['AV Villas',        null,  null, 10.50,  null, 100000],
    ['Banco W',          null,  null, 13.20,  null, 100000],
    ['Banco Contactar',  null,  null, 13.30,  null, 100000],
    ['Pibank',           null,  null, 13.50,  null, 100000]];
  const ins = db.prepare('INSERT INTO rates (entity,min_days,max_days,ea,min_amount,note) VALUES (?,?,?,?,?,?)');
  BANKS.forEach(([e, ...r]) => BANDS.forEach(([a, b, k]) => { if (r[k] != null) ins.run(e, a, b, r[k], r[4], a === 30 ? 'Plazos <90 d: se usa la tasa de 90 d (aprox.)' : null); }));
}
db.prepare("INSERT OR REPLACE INTO meta (k,v) VALUES ('rates_version',?)").run(RATES_VERSION);
module.exports = db;
