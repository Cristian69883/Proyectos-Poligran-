# FinPoli (Node.js + SQLite)

## Ejecutar
```bash
npm install
cp .env.example .env     # y cambia JWT_SECRET
npm start                # http://localhost:3000
npm test                 # pruebas del motor financiero
```

## Estructura
- `src/db.js` esquema SQLite + semillas (categorías "Vida Poli" y tasas)
- `src/finance.js` validación + cálculo (bruta, retención, neta, vencimiento, presupuesto diario)
- `src/server.js` API REST con JWT
- `public/index.html` interfaz

## API
POST /api/auth/register · POST /api/auth/login
GET/POST /api/transactions · DELETE /api/transactions/:id · GET /api/summary
GET /api/budget/daily?available=180000&days=23
GET /api/rates · POST /api/simulate · GET /api/simulations
GET /api/me/export · DELETE /api/me   (derechos del titular)

## Pendientes antes de usar con estudiantes reales
1. Reemplazar las tasas de ejemplo de `rates` por las reales de los boletines de la SFC.
2. Confirmar la tarifa de retención en la fuente vigente (`RETENCION_FUENTE`, 4% por defecto).
3. Servir solo por HTTPS, JWT_SECRET largo, backups cifrados del archivo `.db`.
4. Política de tratamiento de datos publicada y registro de la base de datos ante la SIC si aplica.
